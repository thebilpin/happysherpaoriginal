<?php

return [
    'name' => 'OrderSchedule'
];
